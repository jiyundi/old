import jax.numpy as jnp
from   jax import grad, jacfwd


def ELrhs(L):
    """
    L(x, v) is a Python function defining the 
    Lagrangian, and x, v are generalized coordinates 
    and velocities.
    
    ELrhs(L) should return a function def rhs(xv): ... 
    where where xv is the concatenated state [x, v], 
    and the output is [v, a] (velocities and 
    "accelerations"). 
    
    This is possible because python 
    supports functional programming. Functions are 
    "first-class citizens" in python.
    
    Use jax.grad() and jax.jacfwd() to compute the 
    necessary derivatives for the Euler-Lagrange 
    equation.
    
    You may need to read JAX's documentation to make 
    it work.
    
    Verify correctness on a single harmonic oscillator 
    and confirm that the derived ODE matches the known 
    analytic form. See demo.ipynb.
    
    a = [∂_x L​ − v * (∂_x∂_v L)​] / (∂_v^2 L​)
    """
    def rhs(xv):
        """
        xv is the concatenated state [x, v]
        ELrhs(L(x, v)) --> xv = (x, v)
        """
        x, v = xv[:2], xv[2:]
        
        # derivatives
        Lx  = dL_dx(x, v)
        Lvv = d2L_dvdv(x, v)
        Lvx = d2L_dvdx(x, v)
        
        # acceleration = [Lx​ − v * Lvx​] / Lvv​
        # [Lx​ − v * Lvx​] --> vector b
        # Lvv​            --> matrix a
        # Solves a @ x = b for x, given a and b.
        a = jnp.linalg.solve(a = Lvv.reshape, 
                             b = (Lx - v @ Lvx)
                             )[0]
        
        return jnp.array([v, a])
    
    dL_dx = grad(L, argnums=0) # to be passed to rhs()
    dL_dv = grad(L, argnums=1)
    
    d2L_dvdx = jacfwd(dL_dv, argnums=0) # to rhs()
    d2L_dvdv = jacfwd(dL_dv, argnums=1)
    
    return rhs