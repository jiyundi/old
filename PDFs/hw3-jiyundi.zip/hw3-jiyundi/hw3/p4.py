import jax.numpy as jnp


def L(x, v, m=1.0, l=1.0, g=9.8):
    """
    x = [x1, x2] (2D)
    v = [v1, v2]
    """
    theta1,   theta2 = x # x1 =  theta1, x2 =  theta2
    dtheta1, dtheta2 = v # v1 = dtheta1, v2 = dtheta2
    
    term1 = dtheta2**2 + 4 * dtheta1**2 + \
            3 * dtheta1 * dtheta2 * jnp.cos(theta1 - theta2)
    term2 = 3 * jnp.cos(theta1) + jnp.cos(theta2)
    
    L = (1/6) *m*l**2 * term1 + (1/2) *m*g*l * term2
    
    return L