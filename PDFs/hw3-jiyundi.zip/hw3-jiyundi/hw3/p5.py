import jax.numpy as jnp

from hw3.p2 import RK4
from hw3.p3 import ELrhs
from hw3.p4 import L


def solve(
    theta1, # initial angle for pendulum 1
    theta2, # initial angle for pendulum 2
    omega1, # initial angular velocity for pendulum 1
    omega2, # initial angular velocity for pendulum 2
    t = 0.1,   # total simulation time
    dt = 0.01, # time step size
):
    """
    Use 
        L = L(x, v, m, l, g)    
    from Part 4 as the Lagrangian.
    
    Use 
        rhs(xv) = ELrhs(L(x, v))  
    from Part 3 to get the right-hand side.
    
    Use 
        x, t = RK4(f, x, t, dt, n) 
    from Part 2 to integrate the system.
    
    Return the tuple X, V, T, where:
        X: array of angles over time with shape (n+1, 2).
        V: array of angular velocities with shape (n+1, 2).
        T: array of times with shape (n+1,).
    """
    x = [theta1, theta2]
    v = [omega1, omega2]
    # xv = jnp.array([x, v])
    
    n = int(t // dt)
    T = jnp.linspace(0, t, n+1)
    
    rhs  = ELrhs(L)
    # v, a = rhs(xv)
    
    X, V = RK4(rhs(L(x, v)), x, t, dt, n)
    
    return X, V, T